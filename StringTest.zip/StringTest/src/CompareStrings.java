import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CompareStrings {

	public String str1VsStr2(String str1, String str2) {
		char[] ch1 = str1.toCharArray();
		char[] ch2 = str2.toCharArray();
		int count = 0;
		List list = new ArrayList();
		for (int i = 0; i < ch1.length; i++) {
			for (int j = 0; j < ch2.length; j++) {
				if (ch1[i] == ch2[j]) {
					count++;
				}
			}
			if (count == 0) {
				list.add(ch1[i]);
			}
			count = 0;
		}
		if (list.isEmpty()) {
			return null;
		}
		return list.toString();
	}

	public String str2VsStr1(String str1, String str2) {
		char[] ch1 = str1.toCharArray();
		char[] ch2 = str2.toCharArray();
		int count = 0;
		List list = new ArrayList();
		for (int i = 0; i < ch2.length; i++) {
			for (int j = 0; j < ch1.length; j++) {
				if (ch2[i] == ch1[j]) {
					count++;
				}
			}
			if (count == 0) {
				list.add(ch2[i]);
			}
			count = 0;
		}
		if (list.isEmpty()) {
			return null;
		}
		return list.toString();
	}

	public static void main(String[] args) {

		CompareStrings ms = new CompareStrings();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First String: ");
		String str1 = sc.next();
		System.out.println("Enter Second String: ");
		String str2 = sc.next();
		System.out.println("�utput 1: " + ms.str1VsStr2(str1, str2));
		System.out.println("�utput 2: " + ms.str2VsStr1(str1, str2));
	}

}
